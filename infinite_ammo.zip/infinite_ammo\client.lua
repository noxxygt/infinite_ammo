local enabled = Config.Enabled

local function notify(message)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, false)
end

local function shouldSkipWeapon(weapon)
    return weapon == 0 or Config.BlacklistedWeapons[weapon] == true
end

CreateThread(function()
    while true do
        Wait(Config.CheckInterval)

        if enabled then
            local ped = PlayerPedId()
            local weapon = GetSelectedPedWeapon(ped)

            if not shouldSkipWeapon(weapon) then
                SetPedInfiniteAmmo(ped, true, weapon)
                SetPedInfiniteAmmoClip(ped, Config.InfiniteClip)

                local _, ammoInClip = GetAmmoInClip(ped, weapon)
                if ammoInClip <= 1 then
                    SetPedAmmo(ped, weapon, Config.ReloadAmmo)
                end
            end
        else
            SetPedInfiniteAmmoClip(PlayerPedId(), false)
        end
    end
end)

if Config.AllowToggleCommand then
    RegisterCommand(Config.Command, function()
        enabled = not enabled
        SetPedInfiniteAmmoClip(PlayerPedId(), enabled and Config.InfiniteClip or false)
        notify(enabled and 'Unendlich Munition aktiviert.' or 'Unendlich Munition deaktiviert.')
    end, false)
end

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end

    local ped = PlayerPedId()
    SetPedInfiniteAmmoClip(ped, false)
    SetPedInfiniteAmmo(ped, false, GetSelectedPedWeapon(ped))
end)
