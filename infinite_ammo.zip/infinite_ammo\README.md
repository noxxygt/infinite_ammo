# infinite_ammo

Kleine FiveM-Resource fuer unendlich Munition.

## Installation

```cfg
ensure infinite_ammo
```

## Nutzung

Standard ist unendlich Munition direkt aktiv.

Optionaler Toggle:

```text
/unammo
```

In `config.lua` kannst du den Toggle, Infinite Clip und ausgeschlossene Waffen anpassen.
