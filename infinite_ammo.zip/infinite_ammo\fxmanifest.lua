fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Codex'
description 'Simple infinite ammo resource'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}
