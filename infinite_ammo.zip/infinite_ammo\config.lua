Config = {}

Config.Enabled = true
Config.InfiniteClip = true
Config.ReloadAmmo = 250
Config.CheckInterval = 250

Config.Command = 'unammo'
Config.AllowToggleCommand = true

Config.BlacklistedWeapons = {
    [`WEAPON_UNARMED`] = true,
    [`WEAPON_PETROLCAN`] = true,
    [`WEAPON_FIREEXTINGUISHER`] = true,
    [`WEAPON_SNOWBALL`] = true,
    [`WEAPON_BALL`] = true
}
